# Student Grading System (Java)

This is a simple Java-based desktop application that calculates a student's grade based on three marks using a Swing UI.

## 📁 Structure
- `src/GradeCalculator.java` – Grade logic (backend)
- `src/GradingForm.java` – GUI Form using Swing (frontend)

## 🚀 How to Run

```bash
javac src/GradingForm.java src/GradeCalculator.java
java -cp src GradingForm
```

## ✅ Features
- Java Swing interface
- Real-time grade calculation
- Backend logic in separate class

## 📌 Author
Project created with guidance by ChatGPT for educational purposes.